<?php

$this->addEvaluationInfosToJs();